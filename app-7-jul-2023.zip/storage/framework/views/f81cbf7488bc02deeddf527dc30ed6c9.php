<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.bonusWallet.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-BonusWallet">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bonusWallet.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bonusWallet.fields.user')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bonusWallet.fields.amount')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bonusWallet.fields.type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bonusWallet.fields.method')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bonusWallet.fields.receiver')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bonusWallet.fields.received_from')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bonusWallet.fields.status')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bonusWallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bonusWallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($bonusWallet->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($bonusWallet->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($bonusWallet->user ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($bonusWallet->amount ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($bonusWallet->type ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($bonusWallet->method ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($bonusWallet->receiver ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($bonusWallet->received_from ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\BonusWallet::STATUS_SELECT[$bonusWallet->status] ?? ''); ?>

                            </td>
                            <td>



                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  
  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-BonusWallet:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/admin/bonusWallets/index.blade.php ENDPATH**/ ?>