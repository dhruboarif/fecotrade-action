<?php $__env->startSection('content'); ?>

<div class="card">
    <?php if(Session::has('Money_added')): ?>
                    <div class="alert alert-success d-flex align-items-center" role="alert">
         <svg class="bi flex-shrink-0 me-2" width="24" height="24">
             <use xlink:href="#check-circle-fill" />
         </svg>
         <div>
             <?php echo e(Session::get('Money_added')); ?>

         </div>
     </div>
      <?php elseif(Session::has('Money_rejected')): ?>
                    <div class="alert alert-danger d-flex align-items-center" role="alert">
         <svg class="bi flex-shrink-0 me-2" width="24" height="24">
             <use xlink:href="#check-circle-fill" />
         </svg>
         <div>
             <?php echo e(Session::get('Money_rejected')); ?>

         </div>
     </div>
     
     <?php endif; ?>
    <div class="card-header">
        <?php echo e(trans('cruds.cashWallet.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-CashWallet">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.cashWallet.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.cashWallet.fields.user')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.cashWallet.fields.amount')); ?>

                        </th>
                        <th>
                            Deposit Method
                        </th>
                        <th>
                            Wallet No
                        </th>
                        <th>
                           Transaction Id
                        </th>
                       
                        <th>
                            <?php echo e(trans('cruds.cashWallet.fields.status')); ?>

                        </th>
                         <th>
                            Action
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cashWallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cashWallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($cashWallet->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($cashWallet->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($cashWallet->user->user_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($cashWallet->amount ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($cashWallet->merchant->wallet_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($cashWallet->merchant->wallet_no ?? ''); ?>

                            </td>
                             <td>
                                <?php echo e($cashWallet->txn_id ?? ''); ?>

                            </td>
                            
                            <td>
                                <?php echo e(App\Models\CashWallet::STATUS_SELECT[$cashWallet->status] ?? ''); ?>

                            </td>
                            <td>
                               
                                <?php if($cashWallet->status == 'pending'): ?>
                                 <a class="btn btn-xs btn-success" href="/home/cash-wallet-approve/<?php echo e($cashWallet->id); ?>">
                                        Approve
                                    </a>
                                     <a class="btn btn-xs btn-danger" href="/home/cash-wallet-reject/<?php echo e($cashWallet->id); ?>">
                                        Reject
                                    </a>
                                
                                
                                <?php else: ?> 
                                No Action Needed 
                                <?php endif; ?>



                            </td>
                            <td></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  
  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-CashWallet:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/admin/cashWallets/index.blade.php ENDPATH**/ ?>