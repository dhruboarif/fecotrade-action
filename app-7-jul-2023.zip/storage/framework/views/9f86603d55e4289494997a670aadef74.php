<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.miningWallet.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-MiningWallet">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.miningWallet.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.miningWallet.fields.user')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.miningWallet.fields.amount')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.miningWallet.fields.type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.miningWallet.fields.method')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.miningWallet.fields.receiver')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.miningWallet.fields.received_from')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.miningWallet.fields.status')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $miningWallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $miningWallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($miningWallet->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($miningWallet->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($miningWallet->user ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($miningWallet->amount ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($miningWallet->type ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($miningWallet->method ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($miningWallet->receiver ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($miningWallet->received_from ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\MiningWallet::STATUS_SELECT[$miningWallet->status] ?? ''); ?>

                            </td>
                            <td>



                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  
  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-MiningWallet:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/admin/miningWallets/index.blade.php ENDPATH**/ ?>