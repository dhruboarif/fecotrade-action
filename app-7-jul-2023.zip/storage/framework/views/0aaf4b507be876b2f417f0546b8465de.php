<div class="modal fade text-left" id="addfund" tabindex="-1" role="dialog" aria-labelledby="myModalLabel17" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel17">Add Fund</h4>
                <button type="button" class="btn-primary close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <section id="multiple-column-form">
                  <div class="row">
                      <div class="col-12">
                          <div class="card">

                              <div class="card-body">

                              <form method="post" action="<?php echo e(route('add-fund')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">

                        <div class="mb-3">

                          <?php
                          $admin_wallets= App\Models\AdminWallet::where('status',1)->get();

                           ?>
                           <label for="email-id-column">Select Gateway<span
                                   class="text-danger">*</span></label>
                        <select id="DestinationOptions" name="wallet_id" class="form-control" aria-label="Default select example" required>
                            <option label="Choose Wallet"></option>
                          <?php $__currentLoopData = $admin_wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option id="<?php echo e($payment->wallet_no); ?>" value="<?php echo e($payment->id); ?>"><?php echo e($payment->wallet_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Wallet or Account No.</label>

                            <input type="text" name="wallet_id" disabled id="wallet_id" class="form-control"required/>
                        </div>
                         <div class="mb-3">
                          <label for="exampleInputEmail1" class="form-label">Transaction ID</label>

                          <input type="text" name="txn_id" class="form-control" required/>


                        </div>

                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Amount (Gala)</label>
                            <input type="round" class="form-control" name="amount" placeholder="Enter Amount" id="exampleInputEmail1" aria-describedby="emailHelp" required>

                        </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </section>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Deposit</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Discard</button>
            </div>
              </form>
        </div>
    </div>
</div>
<?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/users/modals/addfundmodal.blade.php ENDPATH**/ ?>