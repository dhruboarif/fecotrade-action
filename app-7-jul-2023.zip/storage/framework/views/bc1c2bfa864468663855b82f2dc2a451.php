<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.generalSetting.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-GeneralSetting">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.generalSetting.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.generalSetting.fields.company_name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.generalSetting.fields.logo')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.generalSetting.fields.favicon')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.generalSetting.fields.company_address')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.generalSetting.fields.contact_email')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.generalSetting.fields.contact_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.generalSetting.fields.currency_name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.generalSetting.fields.currency_symbol')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $generalSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $generalSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($generalSetting->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($generalSetting->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($generalSetting->company_name ?? ''); ?>

                            </td>
                            <td>
                                <?php if($generalSetting->logo): ?>
                                    <a href="<?php echo e($generalSetting->logo->getUrl()); ?>" target="_blank" style="display: inline-block">
                                        <img src="<?php echo e($generalSetting->logo->getUrl('thumb')); ?>">
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($generalSetting->favicon): ?>
                                    <a href="<?php echo e($generalSetting->favicon->getUrl()); ?>" target="_blank" style="display: inline-block">
                                        <img src="<?php echo e($generalSetting->favicon->getUrl('thumb')); ?>">
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($generalSetting->company_address ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($generalSetting->contact_email ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($generalSetting->contact_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($generalSetting->currency_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($generalSetting->currency_symbol ?? ''); ?>

                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general_setting_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.general-settings.show', $generalSetting->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general_setting_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.general-settings.edit', $generalSetting->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>


                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  
  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-GeneralSetting:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/admin/generalSettings/index.blade.php ENDPATH**/ ?>