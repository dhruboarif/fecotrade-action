<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.packageSetting.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.package-settings.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="package_name"><?php echo e(trans('cruds.packageSetting.fields.package_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('package_name') ? 'is-invalid' : ''); ?>" type="text" name="package_name" id="package_name" value="<?php echo e(old('package_name', '')); ?>" required>
                <?php if($errors->has('package_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('package_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packageSetting.fields.package_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="image"><?php echo e(trans('cruds.packageSetting.fields.image')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('image') ? 'is-invalid' : ''); ?>" id="image-dropzone">
                </div>
                <?php if($errors->has('image')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packageSetting.fields.image_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="price"><?php echo e(trans('cruds.packageSetting.fields.price')); ?></label>
                <input class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" type="number" name="price" id="price" value="<?php echo e(old('price', '')); ?>" step="0.01">
                <?php if($errors->has('price')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('price')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packageSetting.fields.price_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="total_roi"><?php echo e(trans('cruds.packageSetting.fields.total_roi')); ?></label>
                <input class="form-control <?php echo e($errors->has('total_roi') ? 'is-invalid' : ''); ?>" type="number" name="total_roi" id="total_roi" value="<?php echo e(old('total_roi', '')); ?>" step="0.01" required>
                <?php if($errors->has('total_roi')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('total_roi')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packageSetting.fields.total_roi_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="daily_roi"><?php echo e(trans('cruds.packageSetting.fields.daily_roi')); ?></label>
                <input class="form-control <?php echo e($errors->has('daily_roi') ? 'is-invalid' : ''); ?>" type="number" name="daily_roi" id="daily_roi" value="<?php echo e(old('daily_roi', '')); ?>" step="0.01" required>
                <?php if($errors->has('daily_roi')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('daily_roi')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packageSetting.fields.daily_roi_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="validity"><?php echo e(trans('cruds.packageSetting.fields.validity')); ?></label>
                <input class="form-control <?php echo e($errors->has('validity') ? 'is-invalid' : ''); ?>" type="number" name="validity" id="validity" value="<?php echo e(old('validity', '')); ?>" step="1" required>
                <?php if($errors->has('validity')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('validity')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packageSetting.fields.validity_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.packageSetting.fields.status')); ?></label>
                <select class="form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status" id="status" required>
                    <option value disabled <?php echo e(old('status', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\PackageSetting::STATUS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('status', '1') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packageSetting.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.imageDropzone = {
    url: '<?php echo e(route('admin.package-settings.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 100,
      height: 100
    },
    success: function (file, response) {
      $('form').find('input[name="image"]').remove()
      $('form').append('<input type="hidden" name="image" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="image"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($packageSetting) && $packageSetting->image): ?>
      var file = <?php echo json_encode($packageSetting->image); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview ?? file.preview_url)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="image" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/admin/packageSettings/create.blade.php ENDPATH**/ ?>