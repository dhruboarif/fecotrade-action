<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.levelSetting.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-LevelSetting">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_1')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_2')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_3')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_4')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_5')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_6')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_7')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_8')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_9')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_10')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_11')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_12')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_13')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_14')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_15')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_16')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_17')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_18')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_19')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.level_20')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.levelSetting.fields.status')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $levelSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $levelSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($levelSetting->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($levelSetting->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_1 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_2 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_3 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_4 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_5 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_6 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_7 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_8 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_9 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_10 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_11 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_12 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_13 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_14 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_15 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_16 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_17 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_18 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_19 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($levelSetting->level_20 ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\LevelSetting::STATUS_SELECT[$levelSetting->status] ?? ''); ?>

                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('level_setting_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.level-settings.show', $levelSetting->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('level_setting_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.level-settings.edit', $levelSetting->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>


                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  
  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-LevelSetting:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/admin/levelSettings/index.blade.php ENDPATH**/ ?>