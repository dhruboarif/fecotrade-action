<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.packageSetting.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.package-settings.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packageSetting.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($packageSetting->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packageSetting.fields.package_name')); ?>

                        </th>
                        <td>
                            <?php echo e($packageSetting->package_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packageSetting.fields.image')); ?>

                        </th>
                        <td>
                            <?php if($packageSetting->image): ?>
                                <a href="<?php echo e($packageSetting->image->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($packageSetting->image->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packageSetting.fields.price')); ?>

                        </th>
                        <td>
                            <?php echo e($packageSetting->price); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packageSetting.fields.total_roi')); ?>

                        </th>
                        <td>
                            <?php echo e($packageSetting->total_roi); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packageSetting.fields.daily_roi')); ?>

                        </th>
                        <td>
                            <?php echo e($packageSetting->daily_roi); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packageSetting.fields.validity')); ?>

                        </th>
                        <td>
                            <?php echo e($packageSetting->validity); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packageSetting.fields.status')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\PackageSetting::STATUS_SELECT[$packageSetting->status] ?? ''); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.package-settings.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/admin/packageSettings/show.blade.php ENDPATH**/ ?>