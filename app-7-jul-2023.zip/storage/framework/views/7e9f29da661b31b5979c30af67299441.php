<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.adminWallet.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.admin-wallets.update", [$adminWallet->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="wallet_name"><?php echo e(trans('cruds.adminWallet.fields.wallet_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('wallet_name') ? 'is-invalid' : ''); ?>" type="text" name="wallet_name" id="wallet_name" value="<?php echo e(old('wallet_name', $adminWallet->wallet_name)); ?>" required>
                <?php if($errors->has('wallet_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('wallet_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.adminWallet.fields.wallet_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="wallet_no"><?php echo e(trans('cruds.adminWallet.fields.wallet_no')); ?></label>
                <input class="form-control <?php echo e($errors->has('wallet_no') ? 'is-invalid' : ''); ?>" type="text" name="wallet_no" id="wallet_no" value="<?php echo e(old('wallet_no', $adminWallet->wallet_no)); ?>" required>
                <?php if($errors->has('wallet_no')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('wallet_no')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.adminWallet.fields.wallet_no_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.adminWallet.fields.status')); ?></label>
                <select class="form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status" id="status">
                    <option value disabled <?php echo e(old('status', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\AdminWallet::STATUS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('status', $adminWallet->status) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.adminWallet.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/admin/adminWallets/edit.blade.php ENDPATH**/ ?>