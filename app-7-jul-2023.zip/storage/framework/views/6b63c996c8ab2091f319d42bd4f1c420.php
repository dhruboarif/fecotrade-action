<?php $__env->startSection('content'); ?>

<div class="card">
    <?php if(Session::has('Money_added')): ?>
                    <div class="alert alert-success d-flex align-items-center" role="alert">
         <svg class="bi flex-shrink-0 me-2" width="24" height="24">
             <use xlink:href="#check-circle-fill" />
         </svg>
         <div>
             <?php echo e(Session::get('Money_added')); ?>

         </div>
     </div>
     <?php endif; ?>
    <div class="card-header">
       My Asset
    </div>

    <div class="card-body">
      
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-myasset">
                <thead>
                    <tr>
                         <th width="20">

                        </th>
                       <th scope="col">SL</th>
                      
                             <th scope="col">PACKAGE</th>
                                           <th scope="col">PURCHASE
                                                DATE</th>


                                           <th scope="col">TOTAL
                                             ROI</th>
                                           <th scope="col">DAILY
                                            ROI
                                            </th>
                                            <th scope="col">RECEIVED DAYS</th>
                                              <th scope="col">REMAINING DAYS</th>
                        <th>
                            &nbsp;
                        </th>
                      
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($row->id); ?>">
                            <td></td>
                       <td ><?php echo e($loop->index+1); ?></td>
                                          <td><?php echo e($row->packages->package_name); ?></td>

                                          <td><?php echo e($row->created_at); ?></td>


                                            <td><?php echo e($row->packages->total_roi); ?></td>
                                            <td><?php echo e(($row->packages->daily_roi)); ?></td>
                                            <?php
                                            $to = \Carbon\Carbon::createFromFormat('Y-m-d H:s:i',$row->created_at);
                                            $from = \Carbon\Carbon::now();

                                            $diff_in_days = $to->diffInDays($from);


                                            //dd($diff_in_days);


                                             ?>


                                             <?php if(($row->packages->validity)-($diff_in_days)< 0): ?>
                                            <td><?php echo e($row->packages->validity); ?></td>
                                            <td>0</td>
                                            
                                            <?php else: ?> 
                                            
                                            <td><?php echo e($diff_in_days); ?></td>
                                            <td><?php echo e(($row->packages->validity)-($diff_in_days)); ?></td>
                                            
                                            <?php endif; ?>

                            <td></td>
                            
                           
                          
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  
  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-myasset:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
 <script type="text/javascript">

            //alert('success');
            //console.log(this.getAttribute('id'));
            //console.log(e.target.options[e.target.selectedIndex].getAttribute('id'));
            //var wallet=  document.getElementById("wallet_id");
            //wallet.innerHTML= id.value;
            document.getElementById('DestinationOptions').addEventListener('change', function (e) {
                var wallet2 = e.target.options[e.target.selectedIndex].getAttribute('id');
                //console.log(wallet2);
                var wallet = document.getElementById("wallet_id").value = wallet2;
                //console.log(wallet);
                //wallet.innerHTML= wallet2;
            });

            //  document.getElementById('').value(id.value);


        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/users/cashwallet/my_asset.blade.php ENDPATH**/ ?>