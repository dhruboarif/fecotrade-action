<?php $__env->startSection('content'); ?>

<div class="card">
    <?php if(Session::has('Money_added')): ?>
                    <div class="alert alert-success d-flex align-items-center" role="alert">
         <svg class="bi flex-shrink-0 me-2" width="24" height="24">
             <use xlink:href="#check-circle-fill" />
         </svg>
         <div>
             <?php echo e(Session::get('Money_added')); ?>

         </div>
     </div>
     <?php endif; ?>
    <div class="card-header">
       Level Bonus History
    </div>

    <div class="card-body">
      
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-levelbonus">
                <thead>
                    <tr>
                         <th width="20">

                        </th>
                       <th scope="col">SL</th>
                      
                             <th scope="col">DATE</th>
                                           <th scope="col">AMOUNT
                                        </th>


                                           <th scope="col">
                                             TYPE</th>
                                           <th scope="col">DESCRIPTION
                                            
                                            </th>
                                            
                        <th>
                            &nbsp;
                        </th>
                      
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transaction_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($row->id); ?>">
                            <td></td>
                       <td ><?php echo e($loop->index+1); ?></td>
                                          

                                          <td><?php echo e($row->created_at); ?></td>


                                            <td><?php echo e($row->amount); ?> GALA</td>
                                            <td><?php echo e(($row->type)); ?></td>
                                           
                                            <td><?php echo e($row->description); ?></td>
                                            

                            <td></td>
                            
                           
                          
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  
  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-levelbonus:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
 <script type="text/javascript">

            //alert('success');
            //console.log(this.getAttribute('id'));
            //console.log(e.target.options[e.target.selectedIndex].getAttribute('id'));
            //var wallet=  document.getElementById("wallet_id");
            //wallet.innerHTML= id.value;
            document.getElementById('DestinationOptions').addEventListener('change', function (e) {
                var wallet2 = e.target.options[e.target.selectedIndex].getAttribute('id');
                //console.log(wallet2);
                var wallet = document.getElementById("wallet_id").value = wallet2;
                //console.log(wallet);
                //wallet.innerHTML= wallet2;
            });

            //  document.getElementById('').value(id.value);


        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/users/level_bonus_history.blade.php ENDPATH**/ ?>