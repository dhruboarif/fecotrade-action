<?php $__env->startSection('content'); ?>
<style>
       .text-right{
           text-align: right;
       }
   </style>

                  <div class="container">
              <h6>Available Amount: <?php echo e($data['cash_wallet'] ? 'Gala '.number_format((float)$data['cash_wallet'], 2, '.', '') : 'Gala 00.00'); ?></h6>
              <hr>
              <h4 class="btn btn-primary">Package List</h4>
            </div>
            <br>
            <?php if(Session::has('purchase_successful')): ?>
            <div class="alert alert-success d-flex align-items-center" role="alert">
            <svg class="bi flex-shrink-0 me-2" width="24" height="24">
            <use xlink:href="#check-circle-fill" />
            </svg>
            <div>
            <?php echo e(Session::get('purchase_successful')); ?>

            </div>
            </div>
             <?php elseif(Session::has('purchase_error')): ?>
            <div class="alert alert-danger d-flex align-items-center" role="alert">
            <svg class="bi flex-shrink-0 me-2" width="24" height="24">
            <use xlink:href="#check-circle-fill" />
            </svg>
            <div>
            <?php echo e(Session::get('purchase_error')); ?>

            </div>
            </div>
            <?php endif; ?>
            <br>
            <br>
            <div class="bd-example">
            <div class="row  row-cols-1 row-cols-md-2 g-4">
              <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card">
                      <br>
                     
                      <div class="text-center">
                          
                         <a href="<?php echo e($row->image->getUrl()); ?>" target="_blank" style="height:100px;width:100px;" class="bd-placeholder-img card-img-top" width="20%" height="20%">
                                        <img src="<?php echo e($row->image->getUrl('thumb')); ?>">
                                    </a>
                      </div>
                      <hr>

                      <div class="card-body">
                        <div class="input-group mb-3">
                        <!-- <span class="input-group-text" id="basic-addon1"></span> -->
                        <input disabled type="text" class="form-control" style="color:#D98019; font-weight:100%;" value="<?php echo e($row->package_name); ?>" >
                          </div>
                            <div class="input-group mb-3">
                            <span class="input-group-text text-right"  id="basic-addon1" style="color:#D98019;width: 70%; font-weight:100%;">Price (Gala)</span>
                            <input disabled type="text" class="form-control" value="<?php echo e($row->price); ?>" >
                              </div>
                              <div class="input-group mb-3">
                              <span class="input-group-text text-right" style="color:#D98019; width: 70%; font-weight:100%;" id="basic-addon1">Total ROI</span>
                              <input disabled type="text" class="form-control" value="<?php echo e($row->total_roi); ?>" >
                                </div>
                                <div class="input-group mb-3">
                                <span class="input-group-text text-right" style="color:#D98019; width: 70%; font-weight:100%;" id="basic-addon1">Daily ROI</span>
                                <input disabled type="text" class="form-control" value="<?php echo e($row->daily_roi); ?>" >
                                  </div>
                                  <div class="input-group mb-3">
                                  <span class="input-group-text text-right" style="color:#D98019; width: 70%; font-weight:100%;" id="basic-addon1">
                                                                                      Validity (days)</span>
                                  <input disabled type="text" class="form-control" value="<?php echo e($row->validity); ?>" >
                                    </div>
                                    <div class="input-group mb-3">
                                  <span class="input-group-text text-right" style="color:#D98019; width: 70%; font-weight:100%;" id="basic-addon1">
                                                                                      No of Level Bonus</span>
                                  <input disabled type="text" class="form-control" value="<?php echo e($row->no_of_levels); ?>" >
                                    </div>
                                    <div class="text-center">
                                      
                                           
                                          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#packagebuymodal<?php echo e($row->id); ?>">Buy Package</button>
                                           <?php echo $__env->make('users.modals.packagebuymodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </form>
                                    </div>

                      </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



              </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fecoadmin/mining.fecotrade.com/resources/views/users/packages.blade.php ENDPATH**/ ?>