<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <title>Insert Category</title>
</head>
<body>
  <div class="container mt-5">
    <h1>Insert Category</h1>
    <?php if(session('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>
    <form id="categoryForm" action="<?php echo e(route('categories.store')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="categoryInput" class="form-label">Category</label>
    <input type="text" class="form-control" id="categoryInput" name="category" placeholder="Category" required>
  </div>
  <!-- <div class="mb-3">
    <label for="subCategoryInput" class="form-label">Sub Category</label>
    <input type="text" class="form-control" id="subCategoryInput" name="sub_category" placeholder="Sub Category" required>
  </div> -->
  <div class="mb-3">
    <label for="categorySlugInput" class="form-label">Category Slug</label>
    <input type="text" class="form-control" id="categorySlugInput" name="category_slug" placeholder="Category Slug" required>
  </div>
  <div class="mb-3">
    <label for="colorCodeInput" class="form-label">Color Code</label>
    <input type="color" class="form-control" id="colorCodeInput" name="category_color_code" placeholder="Color Code" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Status</label>
    <div class="form-check">
      <input class="form-check-input" type="radio" name="status" id="activeStatus" value="1" checked>
      <label class="form-check-label" for="activeStatus">Active</label>
    </div>
    <div class="form-check">
      <input class="form-check-input" type="radio" name="status" id="inactiveStatus" value="0">
      <label class="form-check-label" for="inactiveStatus">Inactive</label>
    </div>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>


  <!-- jQuery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
  $(document).ready(function() {
    // Generate category slug based on the category name
    function generateCategorySlug(categoryName) {
      return categoryName.toLowerCase().replace(/ /g, '-');
    }

    // Update category slug field based on category name
    $('#categoryInput').on('input', function() {
      var categoryName = $(this).val();
      var categorySlug = generateCategorySlug(categoryName);
      $('#categorySlugInput').val(categorySlug);
    });

    // Submit form using AJAX
    $('#categoryForm').submit(function(event) {
    //   event.preventDefault(); // Prevent form from submitting normally

      var formData = $(this).serialize(); // Serialize form data
      var categoryName = $('#categoryInput').val(); // Get the category name

      // Generate category slug based on the category name
      var categorySlug = generateCategorySlug(categoryName);

      // Add the category slug to the form data
      formData += '&category_slug=' + categorySlug;

      // Set the category slug in the input field
      $('#categorySlugInput').val(categorySlug);

      $.ajax({
        url: '<?php echo e(route('categories.store')); ?>',
        type: 'POST',
        data: formData,
        success: function(response) {
          // Handle success
          console.log('Category created successfully.');
          // Reset the form after successful submission
          $('#categoryForm')[0].reset();
        },
        error: function(xhr, status, error) {
          // Handle error
          console.error('Error creating category:', error);
        }
      });
    });
  });
</script>


</body>
</html>
<?php /**PATH D:\laragon\www\ashraful\resources\views/frontend/index.blade.php ENDPATH**/ ?>